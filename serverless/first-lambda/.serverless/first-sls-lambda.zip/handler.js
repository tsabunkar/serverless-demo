// handler.js
module.exports.foo = function(event, context, callback) {
  console.log('--Hello-world from SLS Lambda--');
};
